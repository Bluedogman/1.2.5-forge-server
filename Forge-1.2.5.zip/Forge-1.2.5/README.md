This mc server is a server for legacy mods, like industrial craft, railcraft, and more, check mods/ for more
This was all very complicated and hands on compared to new versions so go to chatGPT for help, thats what I did :/

*IT IS HIGHLY RECCOMENDED NOT TO FUCK WITH MY SHIT AND NOT BREAK IT BECAUSE I WILL KILL YOU*

server.jar is the file for the actual mc server downloaded at https://mcversions.net/download/1.2.5

Go to server.jar extracted and press s and look for start.bat, dont ask me why but it only works if it runs in the same folder as all the class files
start.bat will start and run the server